# test_pycolors.py
import pycolours

def test_colored_basic():
    result = pycolours.colored("test", 255, 0, 0)
    assert "\033[38;2;255;0;0mtest\033[0m" == result

def test_background_basic():
    result = pycolours.background("test", 0, 255, 0)
    assert "\033[48;2;0;255;0mtest\033[0m" == result

def test_hex_to_rgb():
    assert pycolours.hex_to_rgb("#FF0000") == (255, 0, 0)
    assert pycolours.hex_to_rgb("#00FF00") == (0, 255, 0)
    assert pycolours.hex_to_rgb("#0000FF") == (0, 0, 255)

def test_hex_colored():
    result = pycolours.hex_colored("test", "#00FF00")
    assert "\033[38;2;0;255;0mtest\033[0m" == result

def test_bold():
    assert pycolours.bold("test") == "\033[1mtest\033[0m"

def test_underline():
    assert pycolours.underline("test") == "\033[4mtest\033[0m"

def test_reverse():
    assert pycolours.reverse("test") == "\033[7mtest\033[0m"

def test_color_constants():
    assert pycolours.red == (255, 0, 0)
    assert pycolours.navy == (0, 0, 128)
    assert pycolours.gold == (255, 215, 0) 